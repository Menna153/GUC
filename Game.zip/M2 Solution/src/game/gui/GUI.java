package game.gui;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.PriorityQueue;

import game.engine.Battle;
import game.engine.base.Wall;
import game.engine.exceptions.InsufficientResourcesException;
import game.engine.exceptions.InvalidLaneException;
import game.engine.lanes.Lane;
import game.engine.titans.AbnormalTitan;
import game.engine.titans.ArmoredTitan;
import game.engine.titans.ColossalTitan;
import game.engine.titans.PureTitan;
import game.engine.titans.Titan;
import game.engine.weapons.WeaponRegistry;
import game.engine.weapons.factory.WeaponFactory;
import javafx.application.Application;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Pos;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.RadioButton;
import javafx.scene.control.TableView;
import javafx.scene.control.Toggle;
import javafx.scene.control.ToggleGroup;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.Background;
import javafx.scene.layout.BackgroundImage;
import javafx.scene.layout.BackgroundPosition;
import javafx.scene.layout.BackgroundRepeat;
import javafx.scene.layout.BackgroundSize;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Pane;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.shape.Rectangle;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.scene.text.Text;
import javafx.stage.Modality;
import javafx.stage.Stage;

public class GUI extends Application {
	private Battle battleEasy;
	private Battle battleHard;
	private String selectedText;
	private int selectedCode;
	private Image titanImage;
	private ImageView imageView;
	private Image weaponImage1 = new Image("images (3).jpeg");
	private ImageView piercingCannon1 = new ImageView(weaponImage1);
	private ImageView piercingCannon2 = new ImageView(weaponImage1);
	private ImageView piercingCannon3 = new ImageView(weaponImage1);
	private ImageView piercingCannon4 = new ImageView(weaponImage1);
	private ImageView piercingCannon5 = new ImageView(weaponImage1);
	private ImageView piercingCannon6 = new ImageView(weaponImage1);
	private Image weaponImage2 = new Image("images (2).jpeg");
	private ImageView sniperCannon1 = new ImageView(weaponImage2);
	private ImageView sniperCannon2 = new ImageView(weaponImage2);
	private ImageView sniperCannon3 = new ImageView(weaponImage2);
	private ImageView sniperCannon4 = new ImageView(weaponImage2);
	private ImageView sniperCannon5 = new ImageView(weaponImage2);
	private ImageView sniperCannon6 = new ImageView(weaponImage2);
	private Image weaponImage3 = new Image("artillery-isolated-transparent-background_191095-23354.jpg");
	private ImageView volleySpread1 = new ImageView(weaponImage3);
	private ImageView volleySpread2 = new ImageView(weaponImage3);
	private ImageView volleySpread3 = new ImageView(weaponImage3);
	private ImageView volleySpread4 = new ImageView(weaponImage3);
	private ImageView volleySpread5 = new ImageView(weaponImage3);
	private ImageView volleySpread6 = new ImageView(weaponImage3);
	private Image weaponImage4 = new Image("images (1).jpeg");
	private ImageView wallTrap1 = new ImageView(weaponImage4);
	private ImageView wallTrap2 = new ImageView(weaponImage4);
	private ImageView wallTrap3 = new ImageView(weaponImage4);
	private ImageView wallTrap4 = new ImageView(weaponImage4);
	private ImageView wallTrap5 = new ImageView(weaponImage4);
	private ImageView wallTrap6 = new ImageView(weaponImage4);

	
	public GUI() {
		super();
		try {
			this.battleEasy = new Battle(1, 0, 115, 3, 250);

		} catch (IOException e) {
			this.battleEasy = null;
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			this.battleHard = new Battle(1, 0, 115, 5, 125);
			
		} catch (IOException e) {
			this.battleHard = null;
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public GUI(Battle battle) {
		this.battleEasy = battle;
		this.battleHard = battle;
	}

	private void updateGameInfoEasy(Text scoreLabel, Text resourceLabel, Text noturnsLabel, Text phaseLabel, Text wall1Health, Text wall2Health, Text wall3Health, Text dangerLevel, Text dangerLevel1, Text dangerLevel2) {
		scoreLabel.setText("Score: " + battleEasy.getScore());
		resourceLabel.setText("Resources: " + battleEasy.getResourcesGathered());
		noturnsLabel.setText("Number of Turns: " + battleEasy.getNumberOfTurns());
		phaseLabel.setText("Phase: " + battleEasy.getBattlePhase().toString());
		wall1Health.setText("Health: " + battleEasy.getOriginalLanes().get(0).getLaneWall().getCurrentHealth());
		wall2Health.setText("Health: " + battleEasy.getOriginalLanes().get(1).getLaneWall().getCurrentHealth());
		wall3Health.setText("Health: " + battleEasy.getOriginalLanes().get(2).getLaneWall().getCurrentHealth());
		dangerLevel.setText("Danger Level: " + battleEasy.getOriginalLanes().get(0).getDangerLevel());
		dangerLevel1.setText("Danger Level: " + battleEasy.getOriginalLanes().get(1).getDangerLevel());
		dangerLevel2.setText("Danger Level: " + battleEasy.getOriginalLanes().get(2).getDangerLevel());
	}

	private void updateGameInfoHard(Text scoreLabel, Text resourceLabel, Text noturnsLabel, Text phaseLabel, Text wall1Health, Text wall2Health, Text wall3Health, Text wall4Health, Text wall5Health, Text dangerLevel, Text dangerLevel1, Text dangerLevel2, Text dangerLevel3, Text dangerLevel4) {
		scoreLabel.setText("Score: " + battleHard.getScore());
		resourceLabel.setText("Resources: " + battleHard.getResourcesGathered());
		noturnsLabel.setText("Number of Turns: " + battleHard.getNumberOfTurns());
		phaseLabel.setText("Phase: " + battleHard.getBattlePhase().toString());
		wall1Health.setText("Health: " + battleHard.getOriginalLanes().get(0).getLaneWall().getCurrentHealth());
		wall2Health.setText("Health: " + battleHard.getOriginalLanes().get(1).getLaneWall().getCurrentHealth());
		wall3Health.setText("Health: " + battleHard.getOriginalLanes().get(2).getLaneWall().getCurrentHealth());
		wall4Health.setText("Health: " + battleHard.getOriginalLanes().get(3).getLaneWall().getCurrentHealth());
		wall5Health.setText("Health: " + battleHard.getOriginalLanes().get(4).getLaneWall().getCurrentHealth());
		dangerLevel.setText("Danger Level: " + battleHard.getOriginalLanes().get(0).getDangerLevel());
		dangerLevel1.setText("Danger Level: " + battleHard.getOriginalLanes().get(1).getDangerLevel());
		dangerLevel2.setText("Danger Level: " + battleHard.getOriginalLanes().get(2).getDangerLevel());
		dangerLevel3.setText("Danger Level: " + battleHard.getOriginalLanes().get(3).getDangerLevel());
		dangerLevel4.setText("Danger Level: " + battleHard.getOriginalLanes().get(4).getDangerLevel());
	}
	
	private VBox createTitan(Titan titan) {
		if(titan instanceof PureTitan) {
			titanImage = new Image("Yoshimitsu_(T7).png");
			imageView = new ImageView(titanImage);
			imageView.setFitWidth(100); 
	        imageView.setFitHeight(85);
		}
		if(titan instanceof AbnormalTitan) {
			titanImage = new Image("3422771-4guile.png");
			imageView = new ImageView(titanImage);
			imageView.setFitWidth(100); 
	        imageView.setFitHeight(85);
		}
		if(titan instanceof ArmoredTitan) {
			titanImage = new Image("2468851-darkstalkers_resurrection_lord_raptor_01.png");
			imageView = new ImageView(titanImage);
			imageView.setFitWidth(100); 
	        imageView.setFitHeight(85);
		}
		if(titan instanceof ColossalTitan) {
			titanImage = new Image("22860289-akuma1_sf_785.png");
			imageView = new ImageView(titanImage);
			imageView.setFitWidth(100); 
	        imageView.setFitHeight(85);
		} 
        Label healthLabel = new Label("Health: " + titan.getCurrentHealth());
        healthLabel.setTextFill(Color.WHITE);
        VBox vbox = new VBox();
        vbox.setSpacing(5);
        vbox.setAlignment(Pos.CENTER);
        vbox.getChildren().addAll(healthLabel, imageView);
        return vbox;
	}
	public void start(Stage primaryStage) throws Exception {
		try {
			BorderPane root = new BorderPane();
			Scene scene = new Scene(root, 400, 400);
			primaryStage.setScene(scene);
			primaryStage.show();
		} catch (Exception e) {
			e.printStackTrace();
		}

		BorderPane rt = new BorderPane();
		Button play = new Button("Press to play");
		play.setFont(Font.font("System", FontWeight.BOLD, 28));
		play.setTextFill(Color.RED);
		play.setStyle("-fx-background-color: #D3D3D3;");
		play.setPrefWidth(250);
		play.setPrefHeight(60);
		rt.setCenter(play);
		play.setTranslateY(73);
		play.setTranslateX(-320);
		Scene attackOnTitans = new Scene(rt, 1000, 700);
		Image backgroundImage = new Image("scale.png");
		rt.setStyle("-fx-background-image: url(" + backgroundImage.getUrl() + "); " + "-fx-background-size: cover;");
		primaryStage.setScene(attackOnTitans);
		primaryStage.setFullScreen(true);
		primaryStage.show();
		play.setOnAction((EventHandler<ActionEvent>) new EventHandler<ActionEvent>() {
			public void handle(ActionEvent event) {
				BorderPane root = new BorderPane();
				Label mode = new Label("Please select a difficulty mode");
				mode.setFont(Font.font("Georgia", FontWeight.BOLD, 30));
				mode.setTextFill(Color.WHITE);
				Button easy = new Button("Easy");
				Button hard = new Button("Hard");
				easy.setFont(Font.font("System", FontWeight.BOLD, 20));
				hard.setFont(Font.font("System", FontWeight.BOLD, 20));
				easy.setTextFill(Color.BLACK);
				hard.setTextFill(Color.BLACK);
				VBox vbox = new VBox();
				HBox hbox = new HBox();
				hbox.setSpacing(145);
				vbox.setSpacing(30);
				hbox.getChildren().addAll(easy, hard);
				hbox.setAlignment(Pos.CENTER);
				vbox.getChildren().addAll(mode, hbox);
				vbox.setAlignment(Pos.CENTER);
				root.setCenter(vbox);
				Scene s = new Scene(root, 1000, 700);
				Image backgroundImage = new Image("aot-fury-titan-desktop-wallpaper-preview-jpg.jpg");
				root.setStyle("-fx-background-image: url(" + backgroundImage.getUrl() + "); "
						+ "-fx-background-size: cover;");
				primaryStage.setScene(s);
				primaryStage.setFullScreen(true);
				primaryStage.show();
				easy.setOnAction((EventHandler<ActionEvent>) new EventHandler<ActionEvent>() {
					public void handle(ActionEvent event) { // selected easy mode
						BorderPane root1 = new BorderPane();
						Scene s1 = new Scene(root1, 1000, 700);
						Image backgroundImage = new Image("aot-fury-titan-desktop-wallpaper-preview-jpg.jpg");
						root1.setStyle("-fx-background-image: url(" + backgroundImage.getUrl() + "); "
								+ "-fx-background-size: cover;");	
						VBox instructionsv = new VBox(20);
						Text selectedMode = new Text("Selected Mode: Easy");
						Text objective = new Text("Objective: This is a tower defence game, your main goal is to protect the lane walls from the\r\n"
								+ "approaching titans by buying weapons into the lanes to attack the titans present\r\n");
						Text instruction1 = new Text("1.Each turn, you have the option to either pass your turn by clicking on the 'Pass Turn' button\r\n" + 
								"or deploy a weapon into a lane");
						Text instruction2 = new Text("2.You need to click on the 'Weapon Shop' button to chose the desired weapon and lane you want\r\n" + "to deploy the weapon in");
						Text instruction3 = new Text("3.The weapons perform attacks on titans and your score increases whenever a titan is defeated");
						Text instruction4 = new Text("4.You should try to prevent the wall's health from reaching 0");
						Text instruction5 = new Text("5.If the health points of all lane walls reach 0, you lose");
						Text instruction6 = new Text("ENJOY THE GAME :)");
						objective.setFont(Font.font("Georgia", FontWeight.BOLD, 20));
						objective.setFill(Color.WHITE);
						selectedMode.setFont(Font.font("Georgia", FontWeight.BOLD, 20));
						selectedMode.setFill(Color.WHITE);
						instruction1.setFont(Font.font("Georgia", FontWeight.BOLD, 20));
						instruction1.setFill(Color.WHITE);
						instruction2.setFont(Font.font("Georgia", FontWeight.BOLD, 20));
						instruction2.setFill(Color.WHITE);
						instruction3.setFont(Font.font("Georgia", FontWeight.BOLD, 20));
						instruction3.setFill(Color.WHITE);
						instruction4.setFont(Font.font("Georgia", FontWeight.BOLD, 20));
						instruction4.setFill(Color.WHITE);
						instruction5.setFont(Font.font("Georgia", FontWeight.BOLD, 20));
						instruction5.setFill(Color.WHITE);
						instruction6.setFont(Font.font("Georgia", FontWeight.BOLD, 20));
						instruction6.setFill(Color.WHITE);
						Button start = new Button("Press to start");
						start.setFont(Font.font("System", FontWeight.BOLD, 25));
						start.setPrefWidth(200);
						instructionsv.getChildren().addAll(selectedMode, objective, instruction1, instruction2, instruction3, instruction4, instruction5, instruction6, start);
						start.setFont(Font.font("System", FontWeight.BOLD, 16));
						instructionsv.setAlignment(Pos.CENTER);
						root1.setCenter(instructionsv);
						primaryStage.setScene(s1);
						primaryStage.setFullScreen(true);
						start.setOnAction((EventHandler<ActionEvent>) new EventHandler<ActionEvent>() {
							public void handle(ActionEvent event) { // start the game
								BorderPane root2 = new BorderPane();
								Scene s2 = new Scene(root2, 1000, 700);
								String newImageUrl = "d76f97f5614b6e166b7e7f6b73acb3d6.jpg";
								String currentStyle = root2.getStyle();
								root2.setStyle(currentStyle + "-fx-background-image: url('" + newImageUrl + "'); "
										+ "-fx-background-size: cover;");
								piercingCannon1.setFitWidth(40); 
								piercingCannon1.setFitHeight(40);
								piercingCannon2.setFitWidth(40); 
								piercingCannon2.setFitHeight(40);
								piercingCannon3.setFitWidth(40); 
								piercingCannon3.setFitHeight(40);
								sniperCannon1.setFitWidth(40); 
								sniperCannon1.setFitHeight(40);
								sniperCannon2.setFitWidth(40); 
								sniperCannon2.setFitHeight(40);
								sniperCannon3.setFitWidth(40); 
								sniperCannon3.setFitHeight(40);
								volleySpread1.setFitWidth(40); 
								volleySpread1.setFitHeight(40);
								volleySpread2.setFitWidth(40); 
								volleySpread2.setFitHeight(40);
								volleySpread3.setFitWidth(40); 
								volleySpread3.setFitHeight(40);
								wallTrap1.setFitWidth(40); 
								wallTrap1.setFitHeight(40);
								wallTrap2.setFitWidth(40); 
								wallTrap2.setFitHeight(40);
								wallTrap3.setFitWidth(40); 
								wallTrap3.setFitHeight(40);
								VBox images1 = new VBox(10);
								HBox images2 = new HBox(7);
								HBox images3 = new HBox(7);
								Text piercingCannonCount1 = new Text("0");
								Text sniperCannonCount1 = new Text("0");
								Text volleySpreadCount1 = new Text("0");
								Text wallTrapCount1 = new Text("0");
								piercingCannonCount1.setFill(Color.WHITE);
								sniperCannonCount1.setFill(Color.WHITE);
								volleySpreadCount1.setFill(Color.WHITE);
								wallTrapCount1.setFill(Color.WHITE);
								images1.getChildren().addAll(images2,images3);
								images2.getChildren().addAll(piercingCannon1, piercingCannonCount1, sniperCannon1, sniperCannonCount1);
								images3.getChildren().addAll(volleySpread1, volleySpreadCount1, wallTrap1, wallTrapCount1);
								VBox images4 = new VBox(10);
								HBox images5 = new HBox(7);
								HBox images6 = new HBox(7);
								Text piercingCannonCount2 = new Text("0");
								Text sniperCannonCount2 = new Text("0");
								Text volleySpreadCount2 = new Text("0");
								Text wallTrapCount2 = new Text("0");
								piercingCannonCount2.setFill(Color.WHITE);
								sniperCannonCount2.setFill(Color.WHITE);
								volleySpreadCount2.setFill(Color.WHITE);
								wallTrapCount2.setFill(Color.WHITE);
								images4.getChildren().addAll(images5,images6);
								images5.getChildren().addAll(piercingCannon2, piercingCannonCount2, sniperCannon2, sniperCannonCount2);
								images6.getChildren().addAll(volleySpread2, volleySpreadCount2, wallTrap2, wallTrapCount2);
								VBox images7 = new VBox(10);
								HBox images8 = new HBox(7);
								HBox images9 = new HBox(7);
								Text piercingCannonCount3 = new Text("0");
								Text sniperCannonCount3 = new Text("0");
								Text volleySpreadCount3 = new Text("0");
								Text wallTrapCount3 = new Text("0");
								piercingCannonCount3.setFill(Color.WHITE);
								sniperCannonCount3.setFill(Color.WHITE);
								volleySpreadCount3.setFill(Color.WHITE);
								wallTrapCount3.setFill(Color.WHITE);
								images7.getChildren().addAll(images8,images9);
								images8.getChildren().addAll(piercingCannon3, piercingCannonCount3, sniperCannon3, sniperCannonCount3);
								images9.getChildren().addAll(volleySpread3, volleySpreadCount3, wallTrap3, wallTrapCount3);
								Rectangle rectangle = new Rectangle(150, 70, 1350, 200);
								rectangle.setFill(Color.TRANSPARENT); // Set fill color to transparent
								rectangle.setStroke(Color.WHITE); // Set stroke color
								rectangle.setStrokeWidth(2);
								Rectangle rectangle1 = new Rectangle(150, 270, 1350, 200);
								rectangle1.setFill(Color.TRANSPARENT); // Set fill color to transparent
								rectangle1.setStroke(Color.WHITE); // Set stroke color
								rectangle1.setStrokeWidth(2);
								Rectangle rectangle3 = new Rectangle(150, 470, 1350, 200);
								rectangle3.setFill(Color.TRANSPARENT); // Set fill color to transparent
								rectangle3.setStroke(Color.WHITE); // Set stroke color
								rectangle3.setStrokeWidth(2);
								Rectangle wall1 = new Rectangle(20, 70, 130, 200);
								wall1.setFill(Color.TRANSPARENT); // Set fill color to transparent
								wall1.setStroke(Color.WHITE); // Set stroke color
								wall1.setStrokeWidth(2);
								Pane TitansLane1 = new Pane();
								TitansLane1.setLayoutX(150);
								TitansLane1.setLayoutY(80);
								TitansLane1.setPrefHeight(200);
								TitansLane1.setPrefWidth(1350);
								Pane TitansLane2 = new Pane();
								TitansLane2.setLayoutX(150);
								TitansLane2.setLayoutY(280);
								TitansLane2.setPrefHeight(200);
								TitansLane2.setPrefWidth(1350);
								Pane TitansLane3 = new Pane();
								TitansLane3.setLayoutX(150);
								TitansLane3.setLayoutY(480);
								TitansLane3.setPrefHeight(200);
								TitansLane3.setPrefWidth(1350);
								VBox walltext = new VBox();
								walltext.setSpacing(20);
								Lane lane = battleEasy.getOriginalLanes().get(0);
								Wall wall = lane.getLaneWall();
								Text currentHealth = new Text("HP: " + wall.getCurrentHealth());
								Text dangerLevel = new Text("Danger Level: " + lane.getDangerLevel());
								currentHealth.setFont(Font.font(14)); 
								currentHealth.setFill(Color.WHITE); 
								dangerLevel.setFont(Font.font(14)); 
								dangerLevel.setFill(Color.WHITE); 
								walltext.getChildren().addAll(currentHealth, dangerLevel, images1);
								walltext.setLayoutX(25);
								walltext.setLayoutY(80);
								root2.getChildren().addAll(wall1,walltext);
								Rectangle wall2 = new Rectangle(20, 270, 130, 200);
								wall2.setFill(Color.TRANSPARENT); // Set fill color to transparent
								wall2.setStroke(Color.WHITE); // Set stroke color
								wall2.setStrokeWidth(2);
								lane = battleEasy.getOriginalLanes().get(1);
								wall = lane.getLaneWall();
								Text currentHealth1 = new Text("HP: " + wall.getCurrentHealth());
								Text dangerLevel1 = new Text("Danger Level: " + lane.getDangerLevel());
								currentHealth1.setFont(Font.font(14)); 
								currentHealth1.setFill(Color.WHITE); 
								dangerLevel1.setFont(Font.font(14)); 
								dangerLevel1.setFill(Color.WHITE); 
								VBox walltext1 = new VBox();
								walltext1.setSpacing(20);
								walltext1.getChildren().addAll(currentHealth1, dangerLevel1, images4);
								walltext1.setLayoutX(25);
								walltext1.setLayoutY(280);
								root2.getChildren().addAll(wall2,walltext1);
								Rectangle wall3 = new Rectangle(20, 470, 130, 200);
								wall3.setFill(Color.TRANSPARENT); // Set fill color to transparent
								wall3.setStroke(Color.WHITE); // Set stroke color
								wall3.setStrokeWidth(2);
								wall1.setFill(Color.DARKRED);
								wall2.setFill(Color.DARKRED);
								wall3.setFill(Color.DARKRED);
								lane = battleEasy.getOriginalLanes().get(2);
								wall = lane.getLaneWall();
								Text currentHealth2 = new Text("HP: " + wall.getCurrentHealth());
								Text dangerLevel2 = new Text("Danger Level: " + lane.getDangerLevel());
								currentHealth2.setFont(Font.font(14)); 
								currentHealth2.setFill(Color.WHITE); 
								dangerLevel2.setFont(Font.font(14)); 
								dangerLevel2.setFill(Color.WHITE); 
								VBox walltext2 = new VBox();
								walltext2.setSpacing(20);
								walltext2.getChildren().addAll(currentHealth2, dangerLevel2, images7);
								walltext2.setLayoutX(25);
								walltext2.setLayoutY(480);
								root2.getChildren().addAll(wall3,walltext2);
								root2.getChildren().addAll(rectangle, rectangle1, rectangle3);
								root2.getChildren().addAll(TitansLane1, TitansLane2, TitansLane3);
								HBox h = new HBox();
								h.setSpacing(200);
								HBox spacer1 = new HBox();
								spacer1.setPrefWidth(0);
								Text score = new Text("Current score: " + battleEasy.getScore());
								Text turn = new Text("Current turn: " + battleEasy.getNumberOfTurns());
								Text phase = new Text("Current phase: " + battleEasy.getBattlePhase());
								Text resources = new Text("Current Resources: " + battleEasy.getResourcesGathered());
								score.setFill(Color.WHITE);
								turn.setFill(Color.WHITE);
								phase.setFill(Color.WHITE);
								resources.setFill(Color.WHITE);
								score.setFont(Font.font("System", FontWeight.BOLD, 16));
								turn.setFont(Font.font("System", FontWeight.BOLD, 16));
								phase.setFont(Font.font("System", FontWeight.BOLD, 16));
								resources.setFont(Font.font("System", FontWeight.BOLD, 16));
								Button weaponshop = new Button("Weapon shop");
								Button passTurn = new Button("Pass turn");
								weaponshop.setFont(Font.font("System", FontWeight.BOLD, 18));
								passTurn.setFont(Font.font("System", FontWeight.BOLD, 18));
								HBox turns = new HBox();
								turns.setSpacing(35);
								turns.setAlignment(Pos.CENTER);
								VBox spacer = new VBox();
								spacer.setPrefHeight(80); // Set the height of the spacer to move the Button up

								// Create a VBox to contain the Button and spacer
								VBox vbox = new VBox();
								vbox.getChildren().addAll(passTurn, spacer);
								VBox vbox2 = new VBox();
								vbox2.getChildren().addAll(weaponshop, spacer);
								turns.getChildren().addAll(vbox, vbox2);
								root2.setBottom(turns);
								h.getChildren().addAll(spacer1, score, turn, phase, resources);
								root2.setTop(h);
								primaryStage.setScene(s2);
								primaryStage.setFullScreen(true);
								weaponshop.setOnAction((EventHandler<ActionEvent>) new EventHandler<ActionEvent>() {
									public void handle(ActionEvent event) {
										WeaponFactory w = battleHard.getWeaponFactory();
										StackPane newRoot = new StackPane();
										Scene newScene = new Scene(newRoot, 800, 400);
										Stage weaponshopstage = new Stage();
										weaponshopstage.setScene(newScene);
										weaponshopstage.setTitle("Weapon Shop");
										weaponshopstage.initModality(Modality.APPLICATION_MODAL);
										weaponshopstage.initOwner(primaryStage);
										weaponshopstage.show();
										GridPane gridPane = new GridPane();
										gridPane.setVgap(10); // Vertical gap between rows
										gridPane.setHgap(30);
										HashMap<Integer, WeaponRegistry> f = w.getWeaponShop();
										// Iterating over the entries of the HashMap and adding them to the GridPane
										Label selectedLabel = new Label("Select a weapon to purchase:");
										piercingCannon6.setFitWidth(40); 
										piercingCannon6.setFitHeight(40);
										sniperCannon6.setFitWidth(40); 
										sniperCannon6.setFitHeight(40);
										volleySpread6.setFitWidth(40); 
										volleySpread6.setFitHeight(40);
										wallTrap6.setFitWidth(40); 
										wallTrap6.setFitHeight(40);
										gridPane.add(selectedLabel, 0, 0);
										gridPane.add(piercingCannon6, 0, 1);
										gridPane.add(sniperCannon6, 0, 2);
										gridPane.add(volleySpread6, 0, 3);
										gridPane.add(wallTrap6, 0, 4);
										int row = 1;
										ToggleGroup group = new ToggleGroup();
										for (WeaponRegistry value : f.values()) {
										    RadioButton weaponRadioButton = new RadioButton(value.getName());
										    weaponRadioButton.setToggleGroup(group);
										    
										    // Set the code as user data for the radio button
										    weaponRadioButton.setUserData(value.getCode());
										    
										    String typeString;
										    int code = value.getCode();
										    switch(code) {
										        case 1: typeString = "Piercing Cannon";break;
										        case 2: typeString = "Sniper Cannon";break;
										        case 3: typeString = "Volley Spread Cannon";break;
										        case 4: typeString = "Wall Trap";break;
										        default: typeString = "";
										    }
										    
										    Label type = new Label("Type: " + typeString);
										    Label damage = new Label("Damage: " + value.getDamage());
										    Label price = new Label("Price: " + value.getPrice());
										    gridPane.add(weaponRadioButton, 1, row);
										    gridPane.add(type, 2, row);
										    gridPane.add(damage, 3, row);
										    gridPane.add(price, 4, row);
										    row++;
										}
										Label selectedLane = new Label("Select a lane:");
										gridPane.add(selectedLane, 0, 6);
										ToggleGroup groupLanes = new ToggleGroup();
										RadioButton Lane1 = new RadioButton("Lane 1");
										Lane1.setToggleGroup(groupLanes);
										gridPane.add(Lane1, 0, 7);
										RadioButton Lane2 = new RadioButton("Lane 2");
										Lane2.setToggleGroup(groupLanes);
										gridPane.add(Lane2, 1, 7);
										RadioButton Lane3 = new RadioButton("Lane 3");
										Lane3.setToggleGroup(groupLanes);
										gridPane.add(Lane3, 2, 7);
										group.selectedToggleProperty().addListener(new ChangeListener<Toggle>() {
										    @Override
										    public void changed(ObservableValue<? extends Toggle> observable, Toggle oldValue, Toggle newValue) {
										        if (newValue != null) {
										            RadioButton selectedRadioButton = (RadioButton) newValue;
										            String selectedWeapon = selectedRadioButton.getText();
								                    selectedLabel.setText("Selected Weapon: " + selectedWeapon);
										            selectedCode = (int) selectedRadioButton.getUserData();
										        }
										    }
										});
										groupLanes.selectedToggleProperty().addListener(new ChangeListener<Toggle>() {
										    @Override
										    public void changed(ObservableValue<? extends Toggle> observable, Toggle oldValue, Toggle newValue) {
										        if (newValue != null && newValue instanceof RadioButton) {
										            RadioButton selectedRadioButton = (RadioButton) newValue;
										            selectedText = selectedRadioButton.getText(); // Update the selected text
										            selectedLane.setText("Selected Lane: " + selectedText); // Update the label
										        }
										    }
										});
										Button confirm = new Button("Confirm Purchase");
										gridPane.add(confirm,2,10);
										newRoot.getChildren().addAll(gridPane);
										confirm.setOnAction((EventHandler<ActionEvent>) new EventHandler<ActionEvent>() {
											public void handle(ActionEvent event) {
										    int code = selectedCode;
										    Lane lane;
										    switch(selectedText) {
										        case "Lane 1": lane = battleEasy.getOriginalLanes().get(0);break;
										        case "Lane 2": lane = battleEasy.getOriginalLanes().get(1);break;
										        case "Lane 3": lane = battleEasy.getOriginalLanes().get(2);break;
										        default: lane = null; break;  
										    }
											
										    try {
										        battleEasy.purchaseWeapon(code, lane);
										        updateGameInfoEasy(score, resources, turn, phase, currentHealth,currentHealth1,currentHealth2, dangerLevel, dangerLevel1, dangerLevel2); // Update game info after purchase
										        TitansLane1.getChildren().clear();
												TitansLane2.getChildren().clear();
												TitansLane3.getChildren().clear();
												for(int i = 0; i<battleEasy.getOriginalLanes().size(); i++) {
													PriorityQueue<Titan> titansInLane = battleEasy.getOriginalLanes().get(i).getTitans();
													for(Titan t : titansInLane) {
														if(i==0) {
															VBox newTitan = createTitan(t);
															TitansLane1.getChildren().add(newTitan);
															newTitan.setTranslateX(t.getDistance() * 10);
														}
														if(i==1) {
															VBox newTitan = createTitan(t);
															TitansLane2.getChildren().add(newTitan);
															newTitan.setTranslateX(t.getDistance() * 10);
														}
														if(i==2) {
															VBox newTitan = createTitan(t);
															TitansLane3.getChildren().add(newTitan);
															newTitan.setTranslateX(t.getDistance() * 10);
														}
													}
												}
												if(selectedText == "Lane 1") {
											    	if(code==1) {
											    		int count = Integer.parseInt(piercingCannonCount1.getText()) + 1;
											    		String count1 = "" + count;
											    		piercingCannonCount1.setText(count1);
											    	}
											    	if(code==2) {
											    		int count = Integer.parseInt(sniperCannonCount1.getText()) + 1;
											    		String count1 = "" + count;
											    		sniperCannonCount1.setText(count1);
											    	}
											    	if(code==3) {
											    		int count = Integer.parseInt(volleySpreadCount1.getText()) + 1;
											    		String count1 = "" + count;
											    		volleySpreadCount1.setText(count1);
											    	}
											    	if(code==4) {
											    		int count = Integer.parseInt(wallTrapCount1.getText()) + 1;
											    		String count1 = "" + count;
											    		wallTrapCount1.setText(count1);
											    	}
											    }
											    if(selectedText == "Lane 2") {
											    	if(code==1) {
											    		int count = Integer.parseInt(piercingCannonCount2.getText()) + 1;
											    		String count1 = "" + count;
											    		piercingCannonCount2.setText(count1);
											    	}
											    	if(code==2) {
											    		int count = Integer.parseInt(sniperCannonCount2.getText()) + 1;
											    		String count1 = "" + count;
											    		sniperCannonCount2.setText(count1);
											    	}
											    	if(code==3) {
											    		int count = Integer.parseInt(volleySpreadCount2.getText()) + 1;
											    		String count1 = "" + count;
											    		volleySpreadCount2.setText(count1);
											    	}
											    	if(code==4) {
											    		int count = Integer.parseInt(wallTrapCount2.getText()) + 1;
											    		String count1 = "" + count;
											    		wallTrapCount2.setText(count1);
											    	}
											    }
											    if(selectedText == "Lane 3") {
											    	if(code==1) {
											    		int count = Integer.parseInt(piercingCannonCount3.getText()) + 1;
											    		String count1 = "" + count;
											    		piercingCannonCount3.setText(count1);
											    	}
											    	if(code==2) {
											    		int count = Integer.parseInt(sniperCannonCount3.getText()) + 1;
											    		String count1 = "" + count;
											    		sniperCannonCount3.setText(count1);
											    	}
											    	if(code==3) {
											    		int count = Integer.parseInt(volleySpreadCount3.getText()) + 1;
											    		String count1 = "" + count;
											    		volleySpreadCount3.setText(count1);
											    	}
											    	if(code==4) {
											    		int count = Integer.parseInt(wallTrapCount3.getText()) + 1;
											    		String count1 = "" + count;
											    		wallTrapCount3.setText(count1);
											    	}
											    }
											    if(battleEasy.isGameOver()) {
											    	BorderPane finalRoot = new BorderPane();
													Scene finalScene = new Scene(finalRoot,1000,700);
													finalRoot.setStyle("-fx-background-color: black;");
													VBox gameFinished = new VBox(20);
													Text gameOver = new Text("GAME OVER");
													gameOver.setFont(Font.font("System", FontWeight.BOLD, 70));
													gameOver.setFill(Color.RED);
													Button replay = new Button("Replay");
													replay.setFont(Font.font("System", FontWeight.BOLD, 30));
													replay.setPrefWidth(150);
													replay.setPrefHeight(50);
													Label finalScore = new Label("Score: " + battleEasy.getScore());
													finalScore.setFont(Font.font("System", FontWeight.BOLD, 50));
													finalScore.setTextFill(Color.RED);
													gameFinished.getChildren().addAll(gameOver, finalScore, replay);
													gameFinished.setAlignment(Pos.CENTER);
													finalRoot.setCenter(gameFinished);
													replay.setOnAction(e -> primaryStage.setScene(attackOnTitans));
													primaryStage.setScene(finalScene);
													primaryStage.setFullScreen(true);
														try {
															battleEasy = new Battle(1, 0, 115, 3, 250);

														} catch (IOException e) {
															battleEasy = null;
															// TODO Auto-generated catch block
															e.printStackTrace();
														}
														try {
															battleHard = new Battle(1, 0, 115, 5, 125);
															
														} catch (IOException e) {
															battleHard = null;
															// TODO Auto-generated catch block
															e.printStackTrace();
														}
													
													primaryStage.setScene(finalScene);
													primaryStage.setFullScreen(true);
												}
										    } catch (InsufficientResourcesException e) {
										    	 e.printStackTrace();
										    	Stage resourcesStage = new Stage();
										    	resourcesStage.initModality(Modality.APPLICATION_MODAL);
										    	BorderPane rootError = new BorderPane();
										    	Scene resourcesError = new Scene(rootError, 800,300);
										    	Label errorMessage = new Label("You don't have enough resources to purchase this weapon :(");
										    	errorMessage.setFont(Font.font(25));
										    	Label continuePlaying = new Label("Click 'x' to continue playing");
										    	continuePlaying.setFont(Font.font(25));
										    	VBox message = new VBox(20);
										        message.getChildren().addAll(errorMessage, continuePlaying);
										        rootError.setCenter(message);
										        resourcesStage.setScene(resourcesError);
										        resourcesStage.show();
										       
										    } catch (InvalidLaneException e) {
										        e.printStackTrace();
										        Stage invalidStage = new Stage();
										        invalidStage.initModality(Modality.APPLICATION_MODAL);
										    	BorderPane rootError = new BorderPane();
										    	Scene invalidError = new Scene(rootError, 800,300);
										    	Label errorMessage = new Label("You can't deploy a weapon to a lost lane :(");
										    	errorMessage.setFont(Font.font(25));
										    	Label continuePlaying = new Label("Click 'x' to continue playing");
										    	continuePlaying.setFont(Font.font(25));
										    	VBox message = new VBox(20);
										        message.getChildren().addAll(errorMessage, continuePlaying);
										        rootError.setCenter(message);
										        invalidStage.setScene(invalidError);
										        invalidStage.show();
										    }
										    weaponshopstage.close();
										}
										});
												
									}
								});

								passTurn.setOnAction((EventHandler<ActionEvent>) new EventHandler<ActionEvent>() {
									public void handle(ActionEvent event) { // start of pass
										
										battleEasy.passTurn();
										updateGameInfoEasy(score, resources, turn, phase, currentHealth,currentHealth1,currentHealth2,dangerLevel,dangerLevel1,dangerLevel2);
										TitansLane1.getChildren().clear();
										TitansLane2.getChildren().clear();
										TitansLane3.getChildren().clear();
										for(int i = 0; i<battleEasy.getOriginalLanes().size(); i++) {
											PriorityQueue<Titan> titansInLane = battleEasy.getOriginalLanes().get(i).getTitans();
											for(Titan t : titansInLane) {
												if(i==0) { 
													if(battleEasy.getOriginalLanes().get(i).isLaneLost()) {
														rectangle.setFill(Color.DARKRED);
													}
													else {
														VBox newTitan = createTitan(t);
														TitansLane1.getChildren().add(newTitan);
														newTitan.setTranslateX(t.getDistance() * 10);
													}
												}
												if(i==1) {
													if(battleEasy.getOriginalLanes().get(i).isLaneLost()) {
														rectangle1.setFill(Color.DARKRED);
													}
													else {
														VBox newTitan = createTitan(t);
														TitansLane2.getChildren().add(newTitan);
														newTitan.setTranslateX(t.getDistance() * 10);
													}
												}
												if(i==2) {
													if(battleEasy.getOriginalLanes().get(i).isLaneLost()) {
														TitansLane3.setStyle("-fx-background-color: #FF0000;");
														rectangle3.setFill(Color.DARKRED);
													}
													else {
														VBox newTitan = createTitan(t);
														TitansLane3.getChildren().add(newTitan);
														newTitan.setTranslateX(t.getDistance() * 10);
													}
												}
											}
										}
										if(battleEasy.isGameOver()) {
											BorderPane finalRoot = new BorderPane();
											Scene finalScene = new Scene(finalRoot,1000,700);
											finalRoot.setStyle("-fx-background-color: black;");
											VBox gameFinished = new VBox(20);
											Text gameOver = new Text("GAME OVER");
											gameOver.setFont(Font.font("System", FontWeight.BOLD, 70));
											gameOver.setFill(Color.RED);
											Button replay = new Button("Replay");
											replay.setFont(Font.font("System", FontWeight.BOLD, 30));
											replay.setPrefWidth(150);
											replay.setPrefHeight(50);
											Label finalScore = new Label("Score: " + battleEasy.getScore());
											finalScore.setFont(Font.font("System", FontWeight.BOLD, 50));
											finalScore.setTextFill(Color.RED);
											gameFinished.getChildren().addAll(gameOver, finalScore, replay);
											gameFinished.setAlignment(Pos.CENTER);
											finalRoot.setCenter(gameFinished);
											replay.setOnAction(e -> primaryStage.setScene(attackOnTitans));
											primaryStage.setScene(finalScene);
											primaryStage.setFullScreen(true);
											try {
												battleEasy = new Battle(1, 0, 115, 3, 250);

											} catch (IOException e) {
												battleEasy = null;
												// TODO Auto-generated catch block
												e.printStackTrace();
											}
											try {
												battleHard = new Battle(1, 0, 115, 5, 125);
												
											} catch (IOException e) {
												battleHard = null;
												// TODO Auto-generated catch block
												e.printStackTrace();
											}
										}
										
									}
								}); // end of passturn
							}

						}); // end of START THE GAME

					}
				}); // end of easy mode
				hard.setOnAction((EventHandler<ActionEvent>) new EventHandler<ActionEvent>() {
					public void handle(ActionEvent event) { // selected hard mode
						BorderPane root1 = new BorderPane();
						Scene s1 = new Scene(root1, 1000, 700);
						Image backgroundImage = new Image("aot-fury-titan-desktop-wallpaper-preview-jpg.jpg");
						root1.setStyle("-fx-background-image: url(" + backgroundImage.getUrl() + "); "
								+ "-fx-background-size: cover;");
						VBox instructionsv = new VBox(20);
						Text selectedMode = new Text("Selected Mode: Hard");
						Text objective = new Text("Objective: This is a tower defence game, your main goal is to protect the lane walls from the\r\n"
								+ "approaching titans by buying weapons into the lanes to attack the titans present\r\n");
						Text instruction1 = new Text("1.Each turn, you have the option to either pass your turn by clicking on the 'Pass Turn' button\r\n" + 
								"or deploy a weapon into a lane");
						Text instruction2 = new Text("2.You need to click on the 'Weapon Shop' button to chose the desired weapon and lane you want\r\n" + "to deploy the weapon in");
						Text instruction3 = new Text("3.The weapons perform attacks on titans and your score increases whenever a titan is defeated");
						Text instruction4 = new Text("4.You should try to prevent the wall's health from reaching 0");
						Text instruction5 = new Text("5.If the health points of all lane walls reach 0, you lose");
						Text instruction6 = new Text("ENJOY THE GAME :)");
						objective.setFont(Font.font("Georgia", FontWeight.BOLD, 20));
						objective.setFill(Color.WHITE);
						selectedMode.setFont(Font.font("Georgia", FontWeight.BOLD, 20));
						selectedMode.setFill(Color.WHITE);
						instruction1.setFont(Font.font("Georgia", FontWeight.BOLD, 20));
						instruction1.setFill(Color.WHITE);
						instruction2.setFont(Font.font("Georgia", FontWeight.BOLD, 20));
						instruction2.setFill(Color.WHITE);
						instruction3.setFont(Font.font("Georgia", FontWeight.BOLD, 20));
						instruction3.setFill(Color.WHITE);
						instruction4.setFont(Font.font("Georgia", FontWeight.BOLD, 20));
						instruction4.setFill(Color.WHITE);
						instruction5.setFont(Font.font("Georgia", FontWeight.BOLD, 20));
						instruction5.setFill(Color.WHITE);
						instruction6.setFont(Font.font("Georgia", FontWeight.BOLD, 20));
						instruction6.setFill(Color.WHITE);
						Button start = new Button("Press to start");
						start.setFont(Font.font("System", FontWeight.BOLD, 25));
						start.setPrefWidth(200);
						instructionsv.getChildren().addAll(selectedMode, objective, instruction1, instruction2, instruction3, instruction4, instruction5, instruction6, start);
						start.setFont(Font.font("System", FontWeight.BOLD, 16));
						instructionsv.setAlignment(Pos.CENTER);
						root1.setCenter(instructionsv);
						primaryStage.setScene(s1);
						primaryStage.setFullScreen(true);
						start.setOnAction((EventHandler<ActionEvent>) new EventHandler<ActionEvent>() {
							public void handle(ActionEvent event) { // start the game
								BorderPane root2 = new BorderPane();
								Scene s2 = new Scene(root2, 1000, 700);
								String newImageUrl = "d76f97f5614b6e166b7e7f6b73acb3d6.jpg";
								String currentStyle = root2.getStyle();
								root2.setStyle(currentStyle + "-fx-background-image: url('" + newImageUrl + "'); "
										+ "-fx-background-size: cover;");
								piercingCannon1.setFitWidth(25); 
								piercingCannon1.setFitHeight(25);
								piercingCannon2.setFitWidth(25); 
								piercingCannon2.setFitHeight(25);
								piercingCannon3.setFitWidth(25); 
								piercingCannon3.setFitHeight(25);
								piercingCannon4.setFitWidth(25); 
								piercingCannon4.setFitHeight(25);
								piercingCannon5.setFitWidth(25); 
								piercingCannon5.setFitHeight(25);
								sniperCannon1.setFitWidth(25); 
								sniperCannon1.setFitHeight(25);
								sniperCannon2.setFitWidth(25); 
								sniperCannon2.setFitHeight(25);
								sniperCannon3.setFitWidth(25); 
								sniperCannon3.setFitHeight(25);
								sniperCannon4.setFitWidth(25); 
								sniperCannon4.setFitHeight(25);
								sniperCannon5.setFitWidth(25); 
								sniperCannon5.setFitHeight(25);
								volleySpread1.setFitWidth(25); 
								volleySpread1.setFitHeight(25);
								volleySpread2.setFitWidth(25); 
								volleySpread2.setFitHeight(25);
								volleySpread3.setFitWidth(25); 
								volleySpread3.setFitHeight(25);
								volleySpread4.setFitWidth(25); 
								volleySpread4.setFitHeight(25);
								volleySpread5.setFitWidth(25); 
								volleySpread5.setFitHeight(25);
								wallTrap1.setFitWidth(25); 
								wallTrap1.setFitHeight(25);
								wallTrap2.setFitWidth(25); 
								wallTrap2.setFitHeight(25);
								wallTrap3.setFitWidth(25); 
								wallTrap3.setFitHeight(25);
								wallTrap4.setFitWidth(25); 
								wallTrap4.setFitHeight(25);
								wallTrap5.setFitWidth(25); 
								wallTrap5.setFitHeight(25);
								VBox images1 = new VBox(10);
								HBox images2 = new HBox(10);
								HBox images3 = new HBox(10);
								Text piercingCannonCount1 = new Text("0");
								Text sniperCannonCount1 = new Text("0");
								Text volleySpreadCount1 = new Text("0");
								Text wallTrapCount1 = new Text("0");
								piercingCannonCount1.setFill(Color.WHITE);
								sniperCannonCount1.setFill(Color.WHITE);
								volleySpreadCount1.setFill(Color.WHITE);
								wallTrapCount1.setFill(Color.WHITE);
								images1.getChildren().addAll(images2,images3);
								images2.getChildren().addAll(piercingCannon1, piercingCannonCount1, sniperCannon1, sniperCannonCount1);
								images3.getChildren().addAll(volleySpread1, volleySpreadCount1, wallTrap1, wallTrapCount1);
								VBox images4 = new VBox(10);
								HBox images5 = new HBox(10);
								HBox images6 = new HBox(10);
								Text piercingCannonCount2 = new Text("0");
								Text sniperCannonCount2 = new Text("0");
								Text volleySpreadCount2 = new Text("0");
								Text wallTrapCount2 = new Text("0");
								piercingCannonCount2.setFill(Color.WHITE);
								sniperCannonCount2.setFill(Color.WHITE);
								volleySpreadCount2.setFill(Color.WHITE);
								wallTrapCount2.setFill(Color.WHITE);
								images4.getChildren().addAll(images5,images6);
								images5.getChildren().addAll(piercingCannon2, piercingCannonCount2, sniperCannon2, sniperCannonCount2);
								images6.getChildren().addAll(volleySpread2, volleySpreadCount2, wallTrap2, wallTrapCount2);
								VBox images7 = new VBox(10);
								HBox images8 = new HBox(10);
								HBox images9 = new HBox(10);
								Text piercingCannonCount3 = new Text("0");
								Text sniperCannonCount3 = new Text("0");
								Text volleySpreadCount3 = new Text("0");
								Text wallTrapCount3 = new Text("0");
								piercingCannonCount3.setFill(Color.WHITE);
								sniperCannonCount3.setFill(Color.WHITE);
								volleySpreadCount3.setFill(Color.WHITE);
								wallTrapCount3.setFill(Color.WHITE);
								images7.getChildren().addAll(images8,images9);
								images8.getChildren().addAll(piercingCannon3, piercingCannonCount3, sniperCannon3, sniperCannonCount3);
								images9.getChildren().addAll(volleySpread3, volleySpreadCount3, wallTrap3, wallTrapCount3);
								VBox images10 = new VBox(10);
								HBox images11 = new HBox(10);
								HBox images12 = new HBox(10);
								Text piercingCannonCount4 = new Text("0");
								Text sniperCannonCount4 = new Text("0");
								Text volleySpreadCount4 = new Text("0");
								Text wallTrapCount4 = new Text("0");
								piercingCannonCount4.setFill(Color.WHITE);
								sniperCannonCount4.setFill(Color.WHITE);
								volleySpreadCount4.setFill(Color.WHITE);
								wallTrapCount4.setFill(Color.WHITE);
								images10.getChildren().addAll(images11,images12);
								images11.getChildren().addAll(piercingCannon4, piercingCannonCount4, sniperCannon4, sniperCannonCount4);
								images12.getChildren().addAll(volleySpread4, volleySpreadCount4, wallTrap4, wallTrapCount4);
								VBox images13 = new VBox(10);
								HBox images14 = new HBox(10);
								HBox images15 = new HBox(10);
								Text piercingCannonCount5 = new Text("0");
								Text sniperCannonCount5 = new Text("0");
								Text volleySpreadCount5 = new Text("0");
								Text wallTrapCount5 = new Text("0");
								piercingCannonCount5.setFill(Color.WHITE);
								sniperCannonCount5.setFill(Color.WHITE);
								volleySpreadCount5.setFill(Color.WHITE);
								wallTrapCount5.setFill(Color.WHITE);
								images13.getChildren().addAll(images14,images15);
								images14.getChildren().addAll(piercingCannon5, piercingCannonCount5, sniperCannon5, sniperCannonCount5);
								images15.getChildren().addAll(volleySpread5, volleySpreadCount5, wallTrap5, wallTrapCount5);
								
								
								Rectangle rectangle = new Rectangle(150, 70, 1350, 125);
								rectangle.setFill(Color.TRANSPARENT); // Set fill color to transparent
								rectangle.setStroke(Color.WHITE); // Set stroke color
								rectangle.setStrokeWidth(2);
								Rectangle rectangle1 = new Rectangle(150, 195, 1350, 125);
								rectangle1.setFill(Color.TRANSPARENT); // Set fill color to transparent
								rectangle1.setStroke(Color.WHITE); // Set stroke color
								rectangle1.setStrokeWidth(2);
								Rectangle rectangle3 = new Rectangle(150, 320, 1350, 125);
								rectangle3.setFill(Color.TRANSPARENT); // Set fill color to transparent
								rectangle3.setStroke(Color.WHITE); // Set stroke color
								rectangle3.setStrokeWidth(2);
								Rectangle rectangle4 = new Rectangle(150, 445, 1350, 125);
								rectangle4.setFill(Color.TRANSPARENT); // Set fill color to transparent
								rectangle4.setStroke(Color.WHITE); // Set stroke color
								rectangle4.setStrokeWidth(2);
								Rectangle rectangle5 = new Rectangle(150, 570, 1350, 125);
								rectangle5.setFill(Color.TRANSPARENT); // Set fill color to transparent
								rectangle5.setStroke(Color.WHITE); // Set stroke color
								rectangle5.setStrokeWidth(2);
								Rectangle wall1 = new Rectangle(20, 70, 130, 125);
								wall1.setFill(Color.TRANSPARENT); // Set fill color to transparent
								wall1.setStroke(Color.WHITE); // Set stroke color
								wall1.setStrokeWidth(2);
								Pane TitansLane1 = new Pane();
								TitansLane1.setLayoutX(150);
								TitansLane1.setLayoutY(80);
								TitansLane1.setPrefHeight(125);
								TitansLane1.setPrefWidth(1350);
								Pane TitansLane2 = new Pane();
								TitansLane2.setLayoutX(150);
								TitansLane2.setLayoutY(205);
								TitansLane2.setPrefHeight(125);
								TitansLane2.setPrefWidth(1350);
								Pane TitansLane3 = new Pane();
								TitansLane3.setLayoutX(150);
								TitansLane3.setLayoutY(330);
								TitansLane3.setPrefHeight(125);
								TitansLane3.setPrefWidth(1350);
								Pane TitansLane4 = new Pane();
								TitansLane4.setLayoutX(150);
								TitansLane4.setLayoutY(455);
								TitansLane4.setPrefHeight(125);
								TitansLane4.setPrefWidth(1350);
								Pane TitansLane5 = new Pane();
								TitansLane5.setLayoutX(150);
								TitansLane5.setLayoutY(580);
								TitansLane5.setPrefHeight(125);
								TitansLane5.setPrefWidth(1350);
								VBox walltext = new VBox();
								walltext.setSpacing(5);
								Lane lane = battleHard.getOriginalLanes().get(0);
								Wall wall = lane.getLaneWall();
								Text currentHealth = new Text("HP: " + wall.getCurrentHealth());
								Text dangerLevel = new Text("Danger Level: " + lane.getDangerLevel());
								currentHealth.setFont(Font.font(12)); 
								currentHealth.setFill(Color.WHITE);
								dangerLevel.setFont(Font.font(12)); 
								dangerLevel.setFill(Color.WHITE); 
								walltext.getChildren().addAll(currentHealth, dangerLevel, images1);
								walltext.setLayoutX(25);
								walltext.setLayoutY(85);
								root2.getChildren().addAll(wall1,walltext);
								Rectangle wall2 = new Rectangle(20, 195, 130, 125);
								wall2.setFill(Color.TRANSPARENT); // Set fill color to transparent
								wall2.setStroke(Color.WHITE); // Set stroke color
								wall2.setStrokeWidth(2);
								VBox walltext1 = new VBox();
								walltext1.setSpacing(5);
								lane = battleHard.getOriginalLanes().get(1);
								wall = lane.getLaneWall();
								Text currentHealth1 = new Text("HP: " + wall.getCurrentHealth());
								Text dangerLevel1 = new Text("Danger Level: " + lane.getDangerLevel());
								currentHealth1.setFont(Font.font(12)); 
								currentHealth1.setFill(Color.WHITE);  
								dangerLevel1.setFont(Font.font(12)); 
								dangerLevel1.setFill(Color.WHITE);  
								walltext1.getChildren().addAll(currentHealth1, dangerLevel1, images4);
								walltext1.setLayoutX(25);
								walltext1.setLayoutY(210);
								root2.getChildren().addAll(wall2,walltext1);
								Rectangle wall3 = new Rectangle(20, 320, 130, 125);
								wall3.setFill(Color.TRANSPARENT); // Set fill color to transparent
								wall3.setStroke(Color.WHITE); // Set stroke color
								wall3.setStrokeWidth(2);
								VBox walltext2 = new VBox();
								walltext2.setSpacing(5);
								lane = battleHard.getOriginalLanes().get(2);
								wall = lane.getLaneWall();
								Text currentHealth2 = new Text("HP: " + wall.getCurrentHealth());
								Text dangerLevel2 = new Text("Danger Level: " + lane.getDangerLevel());
								currentHealth2.setFont(Font.font(12)); 
								currentHealth2.setFill(Color.WHITE); 
								dangerLevel2.setFont(Font.font(12)); 
								dangerLevel2.setFill(Color.WHITE); 		
								walltext2.getChildren().addAll(currentHealth2, dangerLevel2, images7);
								walltext2.setLayoutX(25);
								walltext2.setLayoutY(335);
								root2.getChildren().addAll(wall3,walltext2);
								Rectangle wall4 = new Rectangle(20, 445, 130, 125);
								wall4.setFill(Color.TRANSPARENT); // Set fill color to transparent
								wall4.setStroke(Color.WHITE); // Set stroke color
								wall4.setStrokeWidth(2);
								VBox walltext3 = new VBox();
								walltext3.setSpacing(5);
								lane = battleHard.getOriginalLanes().get(3);
								wall = lane.getLaneWall();
								Text currentHealth3 = new Text("HP: " + wall.getCurrentHealth());
								Text dangerLevel3 = new Text("Danger Level: " + lane.getDangerLevel());
								currentHealth3.setFont(Font.font(12)); 
								currentHealth3.setFill(Color.WHITE); 
								dangerLevel3.setFont(Font.font(12)); 
								dangerLevel3.setFill(Color.WHITE);
								walltext3.getChildren().addAll(currentHealth3, dangerLevel3, images10);
								walltext3.setLayoutX(25);
								walltext3.setLayoutY(460);
								root2.getChildren().addAll(wall4,walltext3);
								Rectangle wall5 = new Rectangle(20, 570, 130, 125);
								wall5.setFill(Color.TRANSPARENT); // Set fill color to transparent
								wall5.setStroke(Color.WHITE); // Set stroke color
								wall5.setStrokeWidth(2);
								VBox walltext4 = new VBox();
								walltext4.setSpacing(5);
								lane = battleHard.getOriginalLanes().get(4);
								wall = lane.getLaneWall();
								Text currentHealth4 = new Text("HP: " + wall.getCurrentHealth());
								Text dangerLevel4 = new Text("Danger Level: " + lane.getDangerLevel());
								currentHealth4.setFont(Font.font(12)); 
								currentHealth4.setFill(Color.WHITE); 
								dangerLevel4.setFont(Font.font(12)); 
								dangerLevel4.setFill(Color.WHITE); 
								walltext4.getChildren().addAll(currentHealth4, dangerLevel4, images13);
								walltext4.setLayoutX(25);
								walltext4.setLayoutY(585);
								root2.getChildren().addAll(wall5,walltext4);
								wall1.setFill(Color.DARKRED);
								wall2.setFill(Color.DARKRED);
								wall3.setFill(Color.DARKRED);
								wall4.setFill(Color.DARKRED);
								wall5.setFill(Color.DARKRED);
								root2.getChildren().addAll(rectangle, rectangle1, rectangle3, rectangle4, rectangle5);
								root2.getChildren().addAll(TitansLane1, TitansLane2, TitansLane3, TitansLane4, TitansLane5);
								HBox h = new HBox();
								h.setSpacing(200);
								Text score = new Text("Current score: " + battleHard.getScore());
								Text turn = new Text("Current turn: " + battleHard.getNumberOfTurns());
								Text phase = new Text("Current phase: " + battleHard.getBattlePhase());
								Text resources = new Text("Current Resources: " + battleHard.getResourcesGathered());
								score.setFill(Color.WHITE);
								turn.setFill(Color.WHITE);
								phase.setFill(Color.WHITE);
								resources.setFill(Color.WHITE);
								Button weaponshop = new Button("Weapon shop");
								score.setFont(Font.font("System", FontWeight.BOLD, 16));
								turn.setFont(Font.font("System", FontWeight.BOLD, 16));
								phase.setFont(Font.font("System", FontWeight.BOLD, 16));
								resources.setFont(Font.font("System", FontWeight.BOLD, 16));
								HBox spacer1 = new HBox();
								spacer1.setPrefWidth(0);
								
								Button passTurn = new Button("Pass turn");	
								passTurn.setFont(Font.font("System", FontWeight.BOLD, 18));
								weaponshop.setFont(Font.font("System", FontWeight.BOLD, 18));
								HBox turns = new HBox();
								turns.setSpacing(35);
								turns.setAlignment(Pos.CENTER);
								VBox spacer = new VBox();
								spacer.setPrefHeight(80); // Set the height of the spacer to move the Button up

								// Create a VBox to contain the Button and spacer
								VBox vbox = new VBox();
								vbox.getChildren().addAll(passTurn, spacer);
								VBox vbox2 = new VBox();
								vbox2.getChildren().addAll(weaponshop, spacer);
								turns.getChildren().addAll(vbox, vbox2);
								root2.setBottom(turns);
								h.getChildren().addAll(spacer1, score, turn, phase, resources);
								root2.setTop(h);
								primaryStage.setScene(s2);
								primaryStage.setFullScreen(true);
								weaponshop.setOnAction((EventHandler<ActionEvent>) new EventHandler<ActionEvent>() {
									public void handle(ActionEvent event) {
										WeaponFactory w = battleHard.getWeaponFactory();
										StackPane newRoot = new StackPane();
										Scene newScene = new Scene(newRoot, 800, 400);
										Stage weaponshopstage = new Stage();
										weaponshopstage.setScene(newScene);
										weaponshopstage.setTitle("Weapon Shop");
										weaponshopstage.initModality(Modality.APPLICATION_MODAL);
										weaponshopstage.initOwner(primaryStage);
										weaponshopstage.show();
										GridPane gridPane = new GridPane();
										gridPane.setVgap(10); // Vertical gap between rows
										gridPane.setHgap(20);
										HashMap<Integer, WeaponRegistry> f = w.getWeaponShop();
										// Iterating over the entries of the HashMap and adding them to the GridPane
										Label selectedLabel = new Label("Select a weapon to purchase:");
										gridPane.add(selectedLabel, 0, 0);
										piercingCannon6.setFitWidth(40); 
										piercingCannon6.setFitHeight(40);
										sniperCannon6.setFitWidth(40); 
										sniperCannon6.setFitHeight(40);
										volleySpread6.setFitWidth(40); 
										volleySpread6.setFitHeight(40);
										wallTrap6.setFitWidth(40); 
										wallTrap6.setFitHeight(40);
										gridPane.add(piercingCannon6, 0, 1);
										gridPane.add(sniperCannon6, 0, 2);
										gridPane.add(volleySpread6, 0, 3);
										gridPane.add(wallTrap6, 0, 4);
										int row = 1;
										ToggleGroup group = new ToggleGroup();
										for (WeaponRegistry value : f.values()) {
										    RadioButton weaponRadioButton = new RadioButton(value.getName());
										    weaponRadioButton.setToggleGroup(group);
										    
										    // Set the code as user data for the radio button
										    weaponRadioButton.setUserData(value.getCode());
										    
										    String typeString;
										    int code = value.getCode();
										    switch(code) {
										        case 1: typeString = "Piercing Cannon";break;
										        case 2: typeString = "Sniper Cannon";break;
										        case 3: typeString = "Volley Spread Cannon";break;
										        case 4: typeString = "Wall Trap";break;
										        default: typeString = "";
										    }
										    
										    Label type = new Label("Type: " + typeString);
										    Label damage = new Label("Damage: " + value.getDamage());
										    Label price = new Label("Price: " + value.getPrice());
										    gridPane.add(weaponRadioButton, 1, row);
										    gridPane.add(type, 2, row);
										    gridPane.add(damage, 3, row);
										    gridPane.add(price, 4, row);
										    row++;
										}
										Label selectedLane = new Label("Select a lane:");
										gridPane.add(selectedLane, 0, 6);
										ToggleGroup groupLanes = new ToggleGroup();
										RadioButton Lane1 = new RadioButton("Lane 1");
										Lane1.setToggleGroup(groupLanes);
										gridPane.add(Lane1, 0, 7);
										RadioButton Lane2 = new RadioButton("Lane 2");
										Lane2.setToggleGroup(groupLanes);
										gridPane.add(Lane2, 1, 7);
										RadioButton Lane3 = new RadioButton("Lane 3");
										Lane3.setToggleGroup(groupLanes);
										gridPane.add(Lane3, 2, 7);
										RadioButton Lane4 = new RadioButton("Lane 4");
										Lane4.setToggleGroup(groupLanes);
										gridPane.add(Lane4, 3, 7);
										RadioButton Lane5 = new RadioButton("Lane 5");
										Lane5.setToggleGroup(groupLanes);
										gridPane.add(Lane5, 4, 7);
										group.selectedToggleProperty().addListener(new ChangeListener<Toggle>() {
										    @Override
										    public void changed(ObservableValue<? extends Toggle> observable, Toggle oldValue, Toggle newValue) {
										        if (newValue != null) {
										            RadioButton selectedRadioButton = (RadioButton) newValue;
										            String selectedWeapon = selectedRadioButton.getText();
								                    selectedLabel.setText("Selected Weapon: " + selectedWeapon);
										            selectedCode = (int) selectedRadioButton.getUserData();
										        }
										    }
										});
										groupLanes.selectedToggleProperty().addListener(new ChangeListener<Toggle>() {
										    @Override
										    public void changed(ObservableValue<? extends Toggle> observable, Toggle oldValue, Toggle newValue) {
										        if (newValue != null && newValue instanceof RadioButton) {
										            RadioButton selectedRadioButton = (RadioButton) newValue;
										            selectedText = selectedRadioButton.getText(); // Update the selected text
										            selectedLane.setText("Selected Lane: " + selectedText); // Update the label
										        }
										    }
										});
										Button confirm = new Button("Confirm Purchase");
										gridPane.add(confirm,2,10);
										newRoot.getChildren().addAll(gridPane);
										confirm.setOnAction((EventHandler<ActionEvent>) new EventHandler<ActionEvent>() {
											public void handle(ActionEvent event) {
												System.out.println("Selected Code: " + selectedCode);
										        System.out.println("Selected Lane: " + selectedText);
										    int code = selectedCode;
										    Lane lane;
										    switch(selectedText) {
										        case "Lane 1": lane = battleHard.getOriginalLanes().get(0);break;
										        case "Lane 2": lane = battleHard.getOriginalLanes().get(1);break;
										        case "Lane 3": lane = battleHard.getOriginalLanes().get(2);break;
										        case "Lane 4": lane = battleHard.getOriginalLanes().get(3);break;
										        case "Lane 5": lane = battleHard.getOriginalLanes().get(4);break;
										        default: lane = null; break;  
										    }
										  
										    try {
										        battleHard.purchaseWeapon(code, lane);
										        updateGameInfoHard(score, resources, turn, phase, currentHealth, currentHealth1, currentHealth2, currentHealth3, currentHealth4, dangerLevel, dangerLevel1, dangerLevel2, dangerLevel3, dangerLevel4); // Update game info after purchase
										        TitansLane1.getChildren().clear();
												TitansLane2.getChildren().clear();
												TitansLane3.getChildren().clear();
												TitansLane4.getChildren().clear();
												TitansLane5.getChildren().clear();
												for(int i = 0; i<battleHard.getOriginalLanes().size(); i++) {
													PriorityQueue<Titan> titansInLane = battleHard.getOriginalLanes().get(i).getTitans();
													for(Titan t : titansInLane) {
														if(i==0) {
															VBox newTitan = createTitan(t);
															TitansLane1.getChildren().add(newTitan);
															newTitan.setTranslateX(t.getDistance() * 10);
														}
														if(i==1) {
															VBox newTitan = createTitan(t);
															TitansLane2.getChildren().add(newTitan);
															newTitan.setTranslateX(t.getDistance() * 10);
														}
														if(i==2) {
															VBox newTitan = createTitan(t);
															TitansLane3.getChildren().add(newTitan);
															newTitan.setTranslateX(t.getDistance() * 10);
														}
														if(i==3) {
															VBox newTitan = createTitan(t);
															TitansLane4.getChildren().add(newTitan);
															newTitan.setTranslateX(t.getDistance() * 10);
														}
														if(i==4) {
															VBox newTitan = createTitan(t);
															TitansLane5.getChildren().add(newTitan);
															newTitan.setTranslateX(t.getDistance() * 10);
														}
													}
												}
												  if(selectedText == "Lane 1") {
												    	if(code==1) {
												    		int count = Integer.parseInt(piercingCannonCount1.getText()) + 1;
												    		String count1 = "" + count;
												    		piercingCannonCount1.setText(count1);
												    	}
												    	if(code==2) {
												    		int count = Integer.parseInt(sniperCannonCount1.getText()) + 1;
												    		String count1 = "" + count;
												    		sniperCannonCount1.setText(count1);
												    	}
												    	if(code==3) {
												    		int count = Integer.parseInt(volleySpreadCount1.getText()) + 1;
												    		String count1 = "" + count;
												    		volleySpreadCount1.setText(count1);
												    	}
												    	if(code==4) {
												    		int count = Integer.parseInt(wallTrapCount1.getText()) + 1;
												    		String count1 = "" + count;
												    		wallTrapCount1.setText(count1);
												    	}
												    }
												    if(selectedText == "Lane 2") {
												    	if(code==1) {
												    		int count = Integer.parseInt(piercingCannonCount2.getText()) + 1;
												    		String count1 = "" + count;
												    		piercingCannonCount2.setText(count1);
												    	}
												    	if(code==2) {
												    		int count = Integer.parseInt(sniperCannonCount2.getText()) + 1;
												    		String count1 = "" + count;
												    		sniperCannonCount2.setText(count1);
												    	}
												    	if(code==3) {
												    		int count = Integer.parseInt(volleySpreadCount2.getText()) + 1;
												    		String count1 = "" + count;
												    		volleySpreadCount2.setText(count1);
												    	}
												    	if(code==4) {
												    		int count = Integer.parseInt(wallTrapCount2.getText()) + 1;
												    		String count1 = "" + count;
												    		wallTrapCount2.setText(count1);
												    	}
												    }
												    if(selectedText == "Lane 3") {
												    	if(code==1) {
												    		int count = Integer.parseInt(piercingCannonCount3.getText()) + 1;
												    		String count1 = "" + count;
												    		piercingCannonCount3.setText(count1);
												    	}
												    	if(code==2) {
												    		int count = Integer.parseInt(sniperCannonCount3.getText()) + 1;
												    		String count1 = "" + count;
												    		sniperCannonCount3.setText(count1);
												    	}
												    	if(code==3) {
												    		int count = Integer.parseInt(volleySpreadCount3.getText()) + 1;
												    		String count1 = "" + count;
												    		volleySpreadCount3.setText(count1);
												    	}
												    	if(code==4) {
												    		int count = Integer.parseInt(wallTrapCount3.getText()) + 1;
												    		String count1 = "" + count;
												    		wallTrapCount3.setText(count1);
												    	}
												    }
												    if(selectedText == "Lane 4") {
												    	if(code==1) {
												    		int count = Integer.parseInt(piercingCannonCount4.getText()) + 1;
												    		String count1 = "" + count;
												    		piercingCannonCount4.setText(count1);
												    	}
												    	if(code==2) {
												    		int count = Integer.parseInt(sniperCannonCount4.getText()) + 1;
												    		String count1 = "" + count;
												    		sniperCannonCount4.setText(count1);
												    	}
												    	if(code==3) {
												    		int count = Integer.parseInt(volleySpreadCount4.getText()) + 1;
												    		String count1 = "" + count;
												    		volleySpreadCount4.setText(count1);
												    	}
												    	if(code==4) {
												    		int count = Integer.parseInt(wallTrapCount4.getText()) + 1;
												    		String count1 = "" + count;
												    		wallTrapCount4.setText(count1);
												    	}
												    }
												    if(selectedText == "Lane 5") {
												    	if(code==1) {
												    		int count = Integer.parseInt(piercingCannonCount5.getText()) + 1;
												    		String count1 = "" + count;
												    		piercingCannonCount5.setText(count1);
												    	}
												    	if(code==2) {
												    		int count = Integer.parseInt(sniperCannonCount5.getText()) + 1;
												    		String count1 = "" + count;
												    		sniperCannonCount5.setText(count1);
												    	}
												    	if(code==3) {
												    		int count = Integer.parseInt(volleySpreadCount5.getText()) + 1;
												    		String count1 = "" + count;
												    		volleySpreadCount5.setText(count1);
												    	}
												    	if(code==4) {
												    		int count = Integer.parseInt(wallTrapCount5.getText()) + 1;
												    		String count1 = "" + count;
												    		wallTrapCount5.setText(count1);
												    	}
												    }
												    if(battleHard.isGameOver()) {
												    	BorderPane finalRoot = new BorderPane();
														Scene finalScene = new Scene(finalRoot,1000,700);												
														finalRoot.setStyle("-fx-background-color: black;");
														VBox gameFinished = new VBox(20);
														Text gameOver = new Text("GAME OVER");
														gameOver.setFont(Font.font("System", FontWeight.BOLD, 70));
														gameOver.setFill(Color.RED);
														Button replay = new Button("Replay");
														replay.setFont(Font.font("System", FontWeight.BOLD, 30));
														replay.setPrefWidth(150);
														replay.setPrefHeight(50);
														Label finalScore = new Label("Score: " + battleHard.getScore());
														finalScore.setFont(Font.font("System", FontWeight.BOLD, 50));
														finalScore.setTextFill(Color.RED);
														gameFinished.getChildren().addAll(gameOver, finalScore, replay);
														gameFinished.setAlignment(Pos.CENTER);
														finalRoot.setCenter(gameFinished);
														replay.setOnAction(e -> primaryStage.setScene(attackOnTitans));
														primaryStage.setScene(finalScene);
														primaryStage.setFullScreen(true);
															try {
																battleEasy = new Battle(1, 0, 115, 3, 250);

															} catch (IOException e) {
																battleEasy = null;
																// TODO Auto-generated catch block
																e.printStackTrace();
															}
															try {
																battleHard = new Battle(1, 0, 115, 5, 125);
																
															} catch (IOException e) {
																battleHard = null;
																// TODO Auto-generated catch block
																e.printStackTrace();
															}
														primaryStage.setScene(finalScene);
														primaryStage.setFullScreen(true);
													}
										    } catch (InsufficientResourcesException e) {
										        e.printStackTrace();
										    	Stage resourcesStage = new Stage();
										    	resourcesStage.initModality(Modality.APPLICATION_MODAL);
										    	BorderPane rootError = new BorderPane();
										    	Scene resourcesError = new Scene(rootError, 800,300);
										    	Label errorMessage = new Label("You don't have enough resources to purchase this weapon :(");
										    	errorMessage.setFont(Font.font(25));
										    	Label continuePlaying = new Label("Click 'x' to continue playing");
										    	continuePlaying.setFont(Font.font(25));
										        VBox message = new VBox(20);
										        message.getChildren().addAll(errorMessage, continuePlaying);
										        rootError.setCenter(message);
										        resourcesStage.setScene(resourcesError);
										        resourcesStage.show();
										    } catch (InvalidLaneException e) {
										        e.printStackTrace();
										        e.printStackTrace();
										        Stage invalidStage = new Stage();
										        invalidStage.initModality(Modality.APPLICATION_MODAL);
										    	BorderPane rootError = new BorderPane();
										    	Scene invalidError = new Scene(rootError, 800,300);
										    	Label errorMessage = new Label("You can't deploy a weapon to a lost lane :(");
										    	errorMessage.setFont(Font.font(25));
										    	Label continuePlaying = new Label("Click 'x' to continue playing");
										    	continuePlaying.setFont(Font.font(25));VBox message = new VBox(20);
										        message.getChildren().addAll(errorMessage, continuePlaying);
										        rootError.setCenter(message);
										        invalidStage.setScene(invalidError);
										        invalidStage.show();
										    }
										    weaponshopstage.close();
										}
										});
												
									}
								});
								
								passTurn.setOnAction((EventHandler<ActionEvent>) new EventHandler<ActionEvent>() {
									public void handle(ActionEvent event) {
										battleHard.passTurn();
										updateGameInfoHard(score, resources, turn, phase, currentHealth, currentHealth1, currentHealth2, currentHealth3, currentHealth4, dangerLevel, dangerLevel1, dangerLevel2, dangerLevel3, dangerLevel4);
										TitansLane1.getChildren().clear();
										TitansLane2.getChildren().clear();
										TitansLane3.getChildren().clear();
										TitansLane4.getChildren().clear();
										TitansLane5.getChildren().clear();
										for(int i = 0; i<battleHard.getOriginalLanes().size(); i++) {
											PriorityQueue<Titan> titansInLane = battleHard.getOriginalLanes().get(i).getTitans();
											for(Titan t : titansInLane) {
												if(i==0) { 
													if(battleHard.getOriginalLanes().get(i).isLaneLost()) {
														rectangle.setFill(Color.DARKRED);
													}
													else {
														VBox newTitan = createTitan(t);
														TitansLane1.getChildren().add(newTitan);
														newTitan.setTranslateX(t.getDistance() * 10);
													}
												}
												if(i==1) {
													if(battleHard.getOriginalLanes().get(i).isLaneLost()) {
														rectangle1.setFill(Color.DARKRED);
													}
													else {
														VBox newTitan = createTitan(t);
														TitansLane2.getChildren().add(newTitan);
														newTitan.setTranslateX(t.getDistance() * 10);
													}
												}
												if(i==2) {
													if(battleHard.getOriginalLanes().get(i).isLaneLost()) {
														TitansLane3.setStyle("-fx-background-color: #FF0000;");
														rectangle3.setFill(Color.DARKRED);
													}
													else {
														VBox newTitan = createTitan(t);
														TitansLane3.getChildren().add(newTitan);
														newTitan.setTranslateX(t.getDistance() * 10);
													}
												}
												if(i==3) {
													if(battleHard.getOriginalLanes().get(i).isLaneLost()) {
														TitansLane4.setStyle("-fx-background-color: #FF0000;");
														rectangle4.setFill(Color.DARKRED);
													}
													else {
														VBox newTitan = createTitan(t);
														TitansLane4.getChildren().add(newTitan);
														newTitan.setTranslateX(t.getDistance() * 10);
													}
												}
												if(i==4) {
													if(battleHard.getOriginalLanes().get(i).isLaneLost()) {
														TitansLane5.setStyle("-fx-background-color: #FF0000;");
														rectangle5.setFill(Color.DARKRED);
													}
													else {
														VBox newTitan = createTitan(t);
														TitansLane5.getChildren().add(newTitan);
														newTitan.setTranslateX(t.getDistance() * 10);
													}
												}
											}
										}
										if(battleHard.isGameOver()) {
											BorderPane finalRoot = new BorderPane();
											Scene finalScene = new Scene(finalRoot,1000,700);
											finalRoot.setStyle("-fx-background-color: black;");
											VBox gameFinished = new VBox(20);
											Text gameOver = new Text("GAME OVER");
											gameOver.setFont(Font.font("System", FontWeight.BOLD, 70));
											gameOver.setFill(Color.RED);
											Button replay = new Button("Replay");
											replay.setFont(Font.font("System", FontWeight.BOLD, 30));
											replay.setPrefWidth(150);
											replay.setPrefHeight(50);
											Label finalScore = new Label("Score: " + battleHard.getScore());
											finalScore.setFont(Font.font("System", FontWeight.BOLD, 50));
											finalScore.setTextFill(Color.RED);
											gameFinished.getChildren().addAll(gameOver, finalScore, replay);
											gameFinished.setAlignment(Pos.CENTER);
											finalRoot.setCenter(gameFinished);
											replay.setOnAction(e -> primaryStage.setScene(attackOnTitans));
											primaryStage.setScene(finalScene);
											primaryStage.setFullScreen(true);
											try {
												battleEasy = new Battle(1, 0, 115, 3, 250);

											} catch (IOException e) {
												battleEasy = null;
												// TODO Auto-generated catch block
												e.printStackTrace();
											}
											try {
												battleHard = new Battle(1, 0, 115, 5, 125);
												
											} catch (IOException e) {
												battleHard = null;
												// TODO Auto-generated catch block
												e.printStackTrace();
											}
										}
									}
								});// end of pass turn

							}

						});
					} // end of Hard
				});

			}
		});
	}

	public static void main(String[] args) {
		launch(args);
	}

}
